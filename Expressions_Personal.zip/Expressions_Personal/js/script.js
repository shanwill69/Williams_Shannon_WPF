//what is my average weekday TV viewing

var monday = 4; //hours per day
var tuesday = 3;
var wednesday = 5;
var thursday = 2;
var average = (monday + tuesday + wednesday + thursday)/4; //add days divide by number of days



