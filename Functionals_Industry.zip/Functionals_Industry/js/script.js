//Shannon Williams Functionals Industry July 28, 2014


// how many lines of code can I write in one hour

function writeCode(linesOfCode) { //used parameter and argument

    var perMinute = linesOfCode * 60;
    console.log("I can write " + perMinute + " lines of code per minute");

}

writeCode(3); //called
