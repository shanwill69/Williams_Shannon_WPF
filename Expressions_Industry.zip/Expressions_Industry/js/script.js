//where would I like to work after I graduate

var jobs = ["amazon", "microsoft", "zappos"];

var firstChoice = jobs[2];




