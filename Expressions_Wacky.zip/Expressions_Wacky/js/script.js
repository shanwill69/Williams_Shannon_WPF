//what are Logan's favorite toys and which does he play with most

var faveToy = ["beyBlades" , "matchBox" , "nerfGuns"];
var beyBlades = (3 + 2+ 4 + 1)/4;  //average per week
var matchBox = (4 + 1 + 2 + 3)/4;
var nerfGuns = (6 + 1 + 1 + 4)/4;

// after averaging playtime, nerfGuns win

var winner = faveToy[2];

console.log(winner);
